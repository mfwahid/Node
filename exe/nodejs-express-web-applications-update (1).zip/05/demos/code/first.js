var x = 5;
var y = 3;

function sum(a,b){
	return a+b;
}

console.log(sum(x,y));
